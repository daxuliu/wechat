const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
const db = cloud.database()
exports.main = async (event, context) => {
  const _ = db.command
  var id = event.id
  var index=event.index
  var a =event.anwser
  a[index].like=a[index].like+1
  //var arr = db.collection('help').where({ _id: id }).get({success: function (res) {
    // res.data 包含该记录的数据
    //console.log(res.data)
    //return a=res.data.anwser
  //}})
  
  //console.log(arr)
  
  //var lk = a[index].like+0
  //lk=lk+1
 // a[index].like=lk
  console.log(id)
  try {
    return await db.collection('help').where({
      _id: id
    })
      .update({
        data: {
        anwser:a
        },
      })
  } catch (e) {
    console.error(e)
  }

}