// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()
// 云函数入口函数
exports.main = async (event, context) => {
  const _ = db.command
  var id = event.id
  var username=event.name
  var openid=event.openId
  console.log(id)
  try {
    return await db.collection('user').where({
     openId: openid
    })
      .update({
        data: {
          like: _.push(id),
        
        },
      })
  } catch (e) {
    console.error(e)
  }
}