// miniprogram/pages/help.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tip: '',
    helpitems: app.globalData.helpitems,
    like: true,
    helpid:'',
    aid:'',
    aindex:-1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.findhelp()
    console.log('onload')
    this.setData({
      helpitems: app.globalData.helpitems
    })
    console.log(app.globalData.helpitems)
    console.log(this.data.helpitems)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
this.onLoad()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  bindFormSubmit: function(e) {
      this.findhelp()
      console.log(app.globalData.userInfo)
      if (e.detail.value.question.length == 0) {

        wx.showToast({

          title: '不得为空!',

          icon: 'loading',

          duration: 1500

        })
      } else {
        wx.showToast({

          title: '提交成功!',

          icon: 'success',

          duration: 1500

        })

        var that = this;
        console.log(app.globalData.userInfo)
        var username = app.globalData.userInfo.nickName
        console.log(username)
        var q = e.detail.value.question
        e.detail.value = null
        this.setData({
          tip: ''
        })
        wx.cloud.callFunction({
          // 需调用的云函数名
          name: 'findNotice',
          // 传给云函数的参数
          data: {
            question: q,
            username: username,
            avatarUrl: app.globalData.userInfo.avatarUrl

          },
          success: res => {

          }
        })
      }
    }
    // 成功回调
    ,
  anwser: function(e) {
    this.findhelp()

    if (e.detail.value.anwser.length == 0) {

      wx.showToast({

        title: '不得为空!',

        icon: 'loading',

        duration: 1500

      })
    } else {
      wx.showToast({

        title: '提交成功!',

        icon: 'success',

        duration: 1500

      })

      var that = this;
      console.log(e)
      var username = app.globalData.userInfo.nickName
      var head = app.globalData.userInfo.avatarUrl
      console.log(username)
      var id = e.detail.value.id
      console.log(id)
      var a = e.detail.value.anwser
      e.detail.value.anwser = null //清空表单
      wx.cloud.callFunction({
        // 需调用的云函数名
        name: 'anwserhelp',
        // 传给云函数的参数
        data: {
          head: head,
          anwser: a,
          name: username,
          id: id
        },
        success: res => {

        }
      })
    }
    this.setData({
      tip: ''
    })
  },
  findhelp: function() {
    var that = this;
    console.log('call findhelp')
    //console.log(bname)
    //that.setData({ book: bname })
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'findhelp',
      // 传给云函数的参数
      data: {

      },

      complete: res => {
        // console.log(res.result.data.length)
        // for (var i = 0; i < res.result.data.length; i++) {
        // console.log(i)
        // if (res.result.data[i].name == bname) {
        that.setData({
          helpitems: res.result.data
        })
        console.log(res.result.data)
        // console.log(that.data.user)
        // console.log(res.result.data[i])
        // break
        // }
      }

    })
    // 成功回调

  }
  , like: function (e) {
    console.log(e.detail)
    var id = e.detail.target.dataset.id
    console.log(id)
    var t = this
   this.onLoad()
   var helpid=this.data.helpid

    var l = t.data.like
    if (helpid!=id) {
      wx.cloud.callFunction({
        // 需调用的云函数名
        name: 'helplike',
        // 传给云函数的参数
        data: {
          id: id
        },
        success: res => {
          //console.log(n)
          console.log(l)
          //console.log(this.data.items._id)

        }
      })

      //t.userlike(e)
      //var nms = t.data.items.name
      console.log('pull')
      //console.log(nms)
     // t.findNotice(nms)
      wx.showToast({

        title: '谢谢💗!',

        icon: 'success',

        duration: 1000

      })
      this.setData({helpid:id})
      // t.setData({ like: false })
      // return

    }
    else{
      wx.showToast({

        title: '您喜欢过了!',

        icon: 'loading',

        duration: 500

      
    })
   
    } 
  },
  alike: function (e) {
    console.log(e)
    var id = e.currentTarget.dataset.id
    console.log(id)
    var index = e.currentTarget.dataset.index
    var anwser=e.currentTarget.dataset.anwser
    console.log(anwser)
    var t = this
    //this.onLoad()
    var aid=this.data.aid
    var aindex=this.data.aindex
    var l = t.data.like
    console.log(aindex)
    console.log(index)
    console.log(((aid != id) || (aindex = !index)))
    if ((aid != id)||(aindex=!index)) {
      wx.cloud.callFunction({
        // 需调用的云函数名
        name: 'alike',
        // 传给云函数的参数
        data: {
          id: id,
          index:index,
          anwser:anwser
        },
        success: res => {
          //console.log(n)
          console.log(l)
          //console.log(this.data.items._id)

        }
      })
      this.onLoad()
      //t.userlike(e)
      //var nms = t.data.items.name
      console.log('pull')
      //console.log(nms)
      // t.findNotice(nms)
      wx.showToast({

        title: '谢谢💗!',

        icon: 'success',

        duration: 1000

      })
      this.setData({aid: id })
      this.setData({aindex:index})
      // t.setData({ like: false })
      // return

    }
    else{
      wx.showToast({

        title: '您喜欢过了!',

        icon: 'loading',

        duration: 500

      
    })
   
    } 
  }
})