// miniprogram/pages/user.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: app.globalData.userInfo,
    likebutton: false,
    worksbutton: true,
    user: app.globalData.user
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    //that.getinfo()//获取用户信息
    //console.log(that.data)
    console.log(app.globalData.user)
    console.log(app.globalData.userInfo)
    that.setData({
      userInfo: app.globalData.userInfo
    })
    that.findNotice(app.globalData.user)
    that.likequchong(app.globalData.user)
  },
  openlikes: function(e) {
    var that = this
    var likebutton = that.data.likebutton
    if (likebutton) {
      that.setData({
        likebutton: !likebutton
      })
    } else {
      that.setData({
        likebutton: !likebutton
      })
    }
  },
  test: function() {
    console.log("test")
    var that = this
    var likebutton = that.data.likebutton
    if (likebutton) {
      that.setData({
        likebutton: !likebutton
      })
    } else {
      that.setData({
        likebutton: !likebutton
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    console.log(' onPullDownRefresh')
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    console.log(' onReachBottom')
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  getinfo: function() {
    var that = this
    wx.getUserInfo({
      success: res => {
        app.globalData.userInfo = res.userInfo
        console.log(res.userInfo.nickName)
        that.findUser(res.userInfo.nickName) //找到对应的用户
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  /*findUser: function (nickName) {
     var that = this;
     console.log(nickName)
     wx.cloud.callFunction({
       // 需调用的云函数名
       name: 'getUser',
       // 传给云函数的参数
       data: {

       },

       complete: res => {
        console.log(res.result.data.length)
         for (var i = 0; i < res.result.data.length; i++) {
           console.log(res.result.data[i])
           console.log(res.result.data[i].name)
           console.log(nickName)
           if (res.result.data[i].name == nickName) {
             that.setData({ user: res.result.data[i] })
             that.findNotice(res.result.data[i])//调用函数找到文章！！
             console.log(res.result.data[i])
             break
           }
         }
         

       }
       // 成功回调

     })
   }*/
  findNotice: function(user) {
    var that = this;
    var noticelist = [] //喜欢列表
    //console.log(bname)
    //that.setData({ book: bname })
    console.log(user)
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'helpadd',
      // 传给云函数的参数
      data: {

      },

      complete: res => {
        console.log(res.result.data)
        var like = that.quchong(user.like)
        console.log(like)
        for (var j = 0; j < like.length; j++) {
          console.log(like[i])
          for (var i = 0; i < res.result.data.length; i++) {
            console.log(i)
            if (res.result.data[i]._id == like[j]) {
              noticelist.push(res.result.data[i])
            }
          }
        }
        console.log(noticelist)
        // that.likequchong(noticelist)
        that.setData({
          items: noticelist
        })
      }

      // 成功回调

    })
  },

  jump: function(e) {
    var name = e.currentTarget.dataset.name;
    var url = 'story?name=' + name
    console.log(url)
    wx.navigateTo({
      url: url
    })
  },
  quchong: function(a) {
    var res = [];

    for (var i = 0, len = a.length; i < len; i++) {
      var item = a[i];

      for (var j = 0, jLen = res.length; j < jLen; j++) {
        if (res[j] === item)
          break;
      }

      if (j === jLen)
        res.push(item);
    }

    return res;
  },
  likequchong: function(user) {


    var t = this
    var like = t.quchong(user.like)
    var username = user.name

    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'likequchong',
      // 传给云函数的参数
      data: {
        like: like,
        name: username,
      },
      success: res => {
        //console.log(n)


      }
    })
  }

})