// miniprogram/pages/paihang.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrls: [

      {

        link: 'user',

        url: 'https://6261-baby-2ae74d-1257687976.tcb.qcloud.la/img/lunbo1.png'

      }, {

        link: 'paihang',

        url: 'https://6261-baby-2ae74d-1257687976.tcb.qcloud.la/img/lunbo2.jpg'

      }, {

        link: 'help',

        url: 'https://6261-baby-2ae74d-1257687976.tcb.qcloud.la/img/lunbo3.png'

      }

    ],

    indicatorDots: true, //小点

    autoplay: true, //是否自动轮播

    interval: 3000, //间隔时间

    duration: 3000, //滑动时间
    curNav: '',
    curIndex: 0,
    navLeftItems: [],
    navRightItems: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getleft()
    this.getright()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  getleft: function() {
    var that = this;
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'getleft',
      // 传给云函数的参数
      data: {

      },

      complete: res => {
        console.log('callFunction test result: ', res.result.data)
        that.setData({
          navLeftItems: res.result.data
        })
      }
      // 成功回调

    })

  },
  gettop: function() {
    var that = this;
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'gettop',
      // 传给云函数的参数
      data: {

      },

      complete: res => {
        console.log('callFunction test result: ', res.result.data)
        that.setData({
          top: res.result.data
        })
      }
      // 成功回调

    })
  },
  getright: function() {
    var that = this;
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'getright',
      // 传给云函数的参数
      data: {

      },

      complete: res => {
        console.log('callFunction test result: ', res.result.data)
        that.setData({
          navRightItems: res.result.data,
          typename:'right'
        })
      }
      // 成功回调

    })
  },
  getrightbyname: function (name) {
    var that = this;
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'getrightbyname',
      // 传给云函数的参数
      data: {
      name:name
      },

      complete: res => {
        console.log('callFunction test result: ', res.result.data)
        that.setData({
          navRightItems: res.result.data
        })
      }
      // 成功回调

    })
  },
  jump: function() {},
  switchRightTab: function(e) { 
    // 获取item项的id，和数组的下标值   
    var name=e.currentTarget.dataset.name   
    var id = e.currentTarget.dataset.id
    this.getrightbyname(name)
    this.setData({ typename: name, curNav:id})
    console.log(name)
  }


})