//index.js
//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    imgUrls: [

      {

        link: '../user',

        url: 'https://6261-baby-2ae74d-1257687976.tcb.qcloud.la/img/lunbo1.png'

      }, {

        link: '../paihang',

        url: 'https://6261-baby-2ae74d-1257687976.tcb.qcloud.la/img/lunbo2.jpg'

      }, {

        link: '../help',

        url: 'https://6261-baby-2ae74d-1257687976.tcb.qcloud.la/img/lunbo3.png'

      }

    ],
    userInfo: app.globalData.userInfo,
    hasUserInfo: app.globalData.hasUserInfo,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    str: '',
    flag:true,
    indicatorDots: true,  //小点

    autoplay: true,  //是否自动轮播

    interval: 3000,  //间隔时间

    duration: 3000,
    
  },
  //事件处理函数
  
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  onLoad: function () {
   // this.bindGetUserInfo()
  console.log(app.globalData.user)
    wx.navigateTo({
      url: '../login',
    })
    var that = this;
    //that.getUserInfo(e)
    /*wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'helpadd',
      // 传给云函数的参数
      data: {

      },

      complete: res => {
        console.log('callFunction test result: ', res.result.data[0])
        that.setData({ items: res.result.data[0] })
      }
      // 成功回调

    })*/
   // that.getinfo()
    that.findNotice()



   /* if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
         
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          console.log(res.userInfo)
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }*/
  },
  
  jump: function (e) {
    var name = e.currentTarget.dataset.name;
    console.log(name)
    wx.navigateTo({
      url: '../story?name='+name
    })
  },
  
  findNotice:function(){
    var that = this;
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'helpadd',
      // 传给云函数的参数
      data: {
       
      },
      
      complete: res => {
        console.log('callFunction test result: ', res.result.data)
        that.setData({items:res.result.data})
      }
      // 成功回调
      
    })
  }/*getinfo:function(){
    wx.getUserInfo({
      success: res => {
        app.globalData.userInfo = res.userInfo
        this.findUser(res.userInfo.nickName)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },/*adduser:function(user){
   
     
        var that = this;
        var name= user.nickName
        wx.cloud.callFunction({
          // 需调用的云函数名
          name: 'adduser',
          // 传给云函数的参数
          data: {
           name:name
          },
          success: res => {

          }
        })
      }
    
        // 成功回调

  ,*/ 
 /* bindGetUserInfo: function (e) {
    console.log(this.data.flag)
    this.setData({flag:false})
    console.log(this.data.flag)
    console.log(e.detail.userInfo)
    this.findUser(e.detail.userInfo.nickName)
    
    this.onLoad(e)
  },
 /* findUser: function (nickName) {
    var that = this;
    console.log(nickName)
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'getUser',
      // 传给云函数的参数
      data: {

      },

      complete: res => {
        console.log(res.result.data.length)
        var flag=true
        var u={nickName:nickName}
        for (var i = 0; i < res.result.data.length; i++) {
          console.log(res.result.data[i])
          console.log(res.result.data[i].name)
          console.log(nickName)
          if (res.result.data[i].name == nickName) {
            that.setData({ user: res.result.data[i] })
            flag=false
           // that.findNotice(res.result.data[i])//调用函数找到文章！！
            console.log(res.result.data[i])
            console.log('用户存在')
            break
          } if (flag) {
       // that.adduser(u)//
        
        console.log('new user')
        console.log('call user add!!!!!!!!!!!!!!')
          }
        }


      }
      // 成功回调

    })
  }
*/
,
  bindGetUserInfo: function (e) {
    console.log(this.data.flag)
    this.setData({ flag: false })
    console.log(this.data.flag)
    console.log(e.detail.userInfo)
    app.globalData.userInfo = e.detail.userInfo
    console.log(app.globalData.userInfo)
    this.findUser(e.detail.userInfo.nickName)
    console.log(app.globalData.user)
    wx.navigateBack({
      deleat: 1
    })
    //this.findUser(e.detail.userInfo.nickName)
    //this.onLoad(e)
    /* wx.navigateTo({
       url: 'index/index',
     })*/
  }, imageLoad: function () {
    this.setData({
      imageWidth: wx.getSystemInfoSync().windowWidth
    })
    console.log(wx.getSystemInfoSync().windowWidth)
  },

})
