// miniprogram/pages/story.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    poster: 'http://y.gtimg.cn/music/photo_new/T002R300x300M000003rsKF44GyaSk.jpg?max_age=2592000',
    name: '',
    author: '',
    src: 'http://ws.stream.qqmusic.qq.com/M500001VfvsJ21xFqb.mp3?guid=ffffffff82def4af4b12b3cd9337d5e7&uin=346897220&vkey=6292F51E1E384E06DCBDC9AB7C49FD713D632D313AC4858BACB8DDD29067D3C601481D36E62053BF8DFEAF74C0A5CCFADD6471160CAF3E6A&fromtag=46',
   like:true,
   userInfo: app.globalData.userInfo,
    user: app.globalData.user
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //console.log(options.query)
    var that=this
    that.setData({ userInfo: app.globalData.userInfo })
    that.setData({ user: app.globalData.user })
    var movieid = getApp().requestId;
    var movieIndex = getApp().requestIndex;
    console.log(that.data.user)
    console.log(that.data.userInfo)
    console.log(options.name)
    var nm=options.name
    this.findNotice(nm)
    //this.getinfo()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.audioCtx = wx.createAudioContext('myAudio')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
console.log('pull')
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var t=this
    var nms = t.data.items.name
    console.log('pull')
    console.log(nms)
    t.findNotice(nms)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }, 
  findNotice: function (bname) {
    var that = this;
    console.log(bname)
    that.setData({book:bname})
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'helpadd',
      // 传给云函数的参数
      data: {

      },

      complete: res => {
        console.log(res.result.data.length)
        for(var i=0;i<res.result.data.length;i++){
          console.log(i)
          if(res.result.data[i].name==bname){
          that.setData({ items: res.result.data[i]})
            console.log(that.data.user)
           console.log(res.result.data[i])
           break
          }
        }
        
      }
      // 成功回调

    })
  },backto:function(){
    wx.navigateTo({
      url: "index/index"
    })
  }, audioPlay: function () {
    this.audioCtx.play()
  },
  audioPause: function () {
    this.audioCtx.pause()
  },
  audio14: function () {
    this.audioCtx.seek(14)
  },
  audioStart: function () {
    this.audioCtx.seek(0)
  },
  funplay: function () {
    console.log("audio play");
  },
  funpause: function () {
    console.log("audio pause");
  },
  funtimeupdate: function (u) {
    console.log(u.detail.currentTime);
    console.log(u.detail.duration);
  },
  funended: function () {
    console.log("audio end");
  },
  funerror: function (u) {
    console.log(u.detail.errMsg);
  },
  like:function(e){
    console.log(e.detail)
    var id = this.data.items._id
    var t = this
  console.log(id)
    var l=t.data.like
    if(l){
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'like',
      // 传给云函数的参数
      data: {
       id:id
      },
      success: res => {
//console.log(n)
console.log(l)
console.log(this.data.items._id)

      }
    })
    
    t.userlike(e)
    var nms = t.data.items.name
    console.log('pull')
    console.log(nms)
    t.findNotice(nms)
      wx.showToast({

        title: '谢谢💗!',

        icon: 'success',

        duration: 1500

      })
      t.data.like=false
     // t.setData({ like: false })
     // return

    }
    else{
      wx.showToast({

        title: '您喜欢过了!',

        icon: 'loading',

        duration: 500

      
    })
   
    } 
  }, userlike: function (e) {
    console.log('userlike')
    console.log(e.detail)
    var id = this.data.items._id
    var t = this
    
    var username = t.data.userInfo.nickName
    this.findUser(username)
      wx.cloud.callFunction({
        // 需调用的云函数名
        name: 'userlike',
        // 传给云函数的参数
        data: {
          id: id,
          name:username
        },
        success: res => {
          //console.log(n)
         

        }
      })

     
      
   
      
   

  },
  findUser: function (nickName) {
    var that = this;
    console.log(nickName)
    wx.cloud.callFunction({
      // 需调用的云函数名
      name: 'getUser',
      // 传给云函数的参数
      data: {
        name: nickName
      },

      complete: res => {
        console.log(res.result.data[0])
        var flag = true
        var u = { nickName: nickName }
        // for (var i = 0; i < res.result.data.length; i++) {
        //  console.log(res.result.data[i])
        // console.log(res.result.data[i].name)
        //  console.log(nickName)
        //  if (res.result.data[i].name == nickName) {
        //that.setData({ user: res.result.data[i] })
        app.globalData.user = res.result.data[0]
        // app.setData({user:res.result.data[0]})
        console.log(app.globalData.user)
        if (app.globalData.user == null) {
          that.adduser(nickName)
          console.log('add new user')
        } else { console.log('old user') }
        //  flag = false
        // that.findNotice(res.result.data[i])//调用函数找到文章！！
        //  console.log(res.result.data[i])
        //  console.log('用户存在')
        // break
        // } if (flag) {
        // that.adduser(u)//

        //  console.log('new user')
        // console.log('call user add!!!!!!!!!!!!!!')
      }




      // 成功回调

    })
  }
  }
   

)