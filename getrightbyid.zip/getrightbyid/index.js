// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()
// 云函数入口函数
exports.main = async (event, context) => {
  var id=event.id
  var name=event.name
  var n = ""
  switch (name) {
    case "运动": n = "sport"
      break;
    case "辅助型工具": n = "tool"
      break;
    case "学习教导": n = "learn"
      break;
    case "亲子共处": n = "compare"
      break;
    case "饮食": n = "eat"
      break;
    case "健康": n = "health"
      break;
    case "right":n="right"
      break;


  }
  return db.collection(n).where({_id:id}).get()
}