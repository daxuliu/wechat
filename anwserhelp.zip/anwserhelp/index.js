const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()
// 云函数入口函数
exports.main = async (event, context) => {
  const _ = db.command
  var id = event.id
  var username = event.name
  var anwser=event.anwser
  var head=event.head
  a={usernameofanwser:username,anwser:anwser,head:head,like:0}
  console.log(id)
  try {
    return await db.collection('help').where({
      _id: id
    })
      .update({
        data: {
        anwser:_.push(a)
        },
      })
  } catch (e) {
    console.error(e)
  }
}